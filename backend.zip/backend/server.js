



// Initial dependencies for the server
//imports express.js, defines ports that the backend will be loaded on etc.


var express = require("express");
var { google } = require("googleapis");
var cors = require("cors");
var session = require("express-session");
var app = express();
var PORT = 5000;

//Designates where the app wioll be loaded as it will be used
//in the future to connect the backend and frontend

app.use(


  cors({
    origin: "http://localhost:3000",
    credentials: true,
  })

);


app.use(express.json());

// Initializes the session of the app

app.use(
  session({
    secret: "supersecretkey",
    resave: false,
    saveUninitialized: true,
    cookie: {
      httpOnly: true,
      sameSite: "lax",
    },
  })
);

// This is a very crucial part of the applicaiton
//and the entire gmail api integration as awhole that was discussed extensively
// in the repor. Essentially uses the clientID's and the Client secret from the 
//OAuth google cloud website/app we visited and set up our app on previously
//and uses it to exchange for tokens that can be displayed in the app itself
// in the form of the email content

//basically ensures the user can load all their gmail emails into resteasy without hassle


var CLIENT_ID =
  "522261061824-abm5ijtvmgbs2d9eei2231krahehvp9h.apps.googleusercontent.com";

var CLIENT_SECRET = "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";
var REDIRECT_URI = "http://localhost:5000/auth/callback";



//the permissions the user will have to give the app for it to work properly
// such as displayuing their email, deleting content from email etc. will be asked 
// for permission when signing in gmail account at the start.
var SCOPES = [
  "https://www.googleapis.com/auth/gmail.readonly",
  "https://www.googleapis.com/auth/gmail.send",
  "https://www.googleapis.com/auth/gmail.modify", 
];

var oauth2Client = new google.auth.OAuth2(
  CLIENT_ID,
  CLIENT_SECRET,
  REDIRECT_URI
);




// Helper functions
// are used throuyghout the code 
function requireAuth(req, res) {
  if (!req.session.tokens) {
    res.status(401).json({ error: "User not authenticated" });
    return false;
  }
  oauth2Client.setCredentials(req.session.tokens);
  return true;
}

function lastGoogleErrorMessage(err) {
  try {
    return (
      err?.response?.data?.error?.message ||
      err?.errors?.[0]?.message ||
      err?.message ||
      "Unknown error"
    );
  } catch {
    return "Unknown error";
  }
}



// This uses some recursion to extract HTML data and dsplayh it as emails in the app
//since gmail has a different format, this logic is necessary to properly extract the gmail
//content and display it as intended inside resteasy
function decodeBase64Url(str = "") {
  return Buffer.from(str.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
}


function findBody(payload) {
  if (!payload) return { html: "", text: "" };

  
  if (payload.body && payload.body.data) {
    var data = decodeBase64Url(payload.body.data);
    var mime = payload.mimeType || "";


    if (mime.includes("html")) {

      return { html: data, text: "" };

    }

    return { html: "", text: data };

  }



  
  if (Array.isArray(payload.parts)) {


    // Logic so that html is perferedd throughout
    //keeps things simple and efficent.

    for (var p of payload.parts) {

      var found = findBody(p);
      if (found.html) return found;
    }

    // And if html is nopt found just use plaintext
    //so as to ensure all info is properly extracted

    for (var p of payload.parts) {

      var found = findBody(p);
      if (found.text) return found;

    }
  }

  return { html: "", text: "" };
}


function header(headers, name, fallback = "")

{

  var h = (headers || []).find((x) => x?.name?.toLowerCase() === name.toLowerCase()) ||

    null;

  return h?.value || fallback;
}



// Use the HTTP GET method to ensure proper permisions are recieved to run the application
//requests permissions properly

app.get("/auth", (req, res) => {

  var url = oauth2Client.generateAuthUrl({
    access_type: "offline",
    scope: SCOPES,
    prompt: "consent", 
    include_granted_scopes: true,


  });

  res.redirect(url);

});

// Properly redirects the backend and frontend so that they work together and in sync
//exactly as they are intended to do so

app.get("/auth/callback", async (req, res) => {

  try {


    var code = req.query.code;
    var { tokens } = await oauth2Client.getToken(code);
    req.session.tokens = tokens;
    oauth2Client.setCredentials(tokens);
    res.redirect("http://localhost:3000");


  } catch (err) {

    console.error("OAuth callback error:", err);
    res.status(500).send("OAuth error: " + lastGoogleErrorMessage(err));


  }

});



// Logic to let the user logout if they want
//makes it feel like a proper versatile applicaiton
//and to ensure user privacy, once again uses the GET method

app.post("/auth/logout", (req, res) =>
  
  {

  req.session.destroy(() => {
    res.json({ success: true });

  });

});



//Logic to basically get the inbox 
//uses the GET method to ensure the saved google tokens
//can be processed in the form of emails from the users gmail account
//ensures seamless transition from whatever app the user was using for gmail
//into rest easy
app.get("/emails", async (req, res) => {
  if (!requireAuth(req, res)) return;

  var gmail = google.gmail({ version: "v1", auth: oauth2Client });
  try {
    var listRes = await gmail.users.messages.list({
      userId: "me",

      //for now shows only the last 10 emails, can be adjusted to more if necessary
      //but in my testing I thought 10 to be enough for UI design purposes
      maxResults: 10,
    });


   //FUrther continued logic for all the necessary functionalities

    var messages = await Promise.all(

      (listRes.data.messages || []).map(async (m) => {
        var detail = await gmail.users.messages.get({
          userId: "me",
          id: m.id,
        });


        var headers = detail.data.payload?.headers || [];

        var subject =

          header(headers, "Subject", "(No Subject)");

        var from =

          header(headers, "From", "(Unknown)");

        var date =

          header(headers, "Date", "");


        var snippet = detail.data.snippet || "";
        return { id: m.id, subject, from, date, snippet };


      })
    );



    res.json(messages);

    //error handling logic 
    //incase stuff goes wrong or some emails are not able to be fetched

  } catch (err) {

    console.error("List error:", err);
    res

      .status(500)
      .json({ error: "Failed to fetch emails: " + lastGoogleErrorMessage(err) });

  }

});




// Further logic and more usage of the GET HTTP method to ensure
//that upon clicking at the inbox content at the right, full emails are obtained.
//previosuly, only the inbox was loaded and although you could see summaries of your emails
//you could read the full emails, that has been fixed here


app.get("/emails/:id", async (req, res) => {

  //ofc this requires further permissions
  if (!requireAuth(req, res)) return;

  var gmail = google.gmail({ version: "v1", auth: oauth2Client });
  var id = req.params.id;

  try {
    var detail = await gmail.users.messages.get({
      userId: "me",
      id,
      format: "full",
    });


    var headers = detail.data.payload?.headers || [];
    var subject = header(headers, "Subject", "(No Subject)");
    var from = header(headers, "From", "(Unknown)");
    var date = header(headers, "Date", "");
    var { html, text } = findBody(detail.data.payload);



    res.json
    
    ({


      id,
      subject,
      from,
      date,
      bodyHtml: html,
      bodyText: text,


    });

    //has its own error handling logic 
  } catch (err) 
  
  {
    console.error("Get full email error:", err);
    res.status(500).json({
      error: "Failed to fetch email: " + lastGoogleErrorMessage(err),
    });
  }


});

// last but not least, logic to send emails, is necessary for the email manager
//app toa ctually work as it is intended to.


app.post("/emails/send", async (req, res) => {


  if (!requireAuth(req, res)) return;

  var gmail = google.gmail({ version: "v1", auth: oauth2Client });
  var { to, subject, body } = req.body;

  var raw =

    `To: ${to}\r\n` +
    `Subject: ${subject}\r\n` +
    `Content-Type: text/plain; charset="UTF-8"\r\n\r\n` +
    (body || "");


  var encoded = Buffer.from(raw)

    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");

  try {

    await gmail.users.messages.send({
      userId: "me",
      requestBody: { raw: encoded },
    });


    res.json({ success: true });


  } 
  
  catch (err) {


    console.error("Send error:", err);
    res
      .status(500)
      .json({ error: "Failed to send: " + lastGoogleErrorMessage(err) });
  }


});

// Just some last minute additions, also though I'd add logic that lets me delete emails
//so that the app is really fully functioning as expected from a proper email task manager web app

app.delete("/emails/:id", async (req, res) => {


  if (!requireAuth(req, res)) return;

  var gmail = google.gmail({ version: "v1", auth: oauth2Client });
  var id = req.params.id;

  try {


    //since gmail generally moves items to trash rather than deleting them fully,
    //this logic ensures that it is given preference to first move emails to trash.


    await gmail.users.messages.trash({ userId: "me", id });
    return res.status(204).send(); // no content
  } catch (trashErr) {


    // and if sending there deosnt work, then it can proceed and delete them fully
    //though as per my testing, this has not really been necessary yet even once.


    console.warn("Trash failed, trying hard delete:", lastGoogleErrorMessage(trashErr));


    try {


      await gmail.users.messages.delete({ userId: "me", id });
      return res.status(204).send();


    } 
    
    catch (delErr) {


      console.error("Delete error:", delErr);
      var msg = lastGoogleErrorMessage(delErr);
      var code = delErr?.response?.status || 500;
      return res.status(code).json({ error: "Delete failed: " + msg });

    }

  }


});

// Starting the app ofcourse


app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});


