




// All logic for the app, including all sorts of functionalities are located here

//this is basically the frontend file of the app.

//importing the required dependencies including React
//as well as another css file called resteasy
//which is used to implement the css for the simplified interface file

import React, { useEffect, useState, useCallback, useRef } from "react";
import "./App.css";
import "./resteasy.css"; // scoped styles for the RestEasy view




// Images used
import BeachImage from "./images/BeachImage.jpeg";
import BreathingImage from "./images/BreathingImage.jpg";


//The first section of this entire app's code is just html for the resteasy
//simplified interface application, this is work that was largely done for my feature prototype
//implementation, however it has been modified(based on feedback) to adapt to the final
//project, as per requiremetns and expectations.

function RestEasy() {
 
  return (
    <div className="re-root">
      <header className="re-header"></header>

      {}
      <nav className="re-navbar">
        <div className="re-brand">
          <span className="re-brand-name">RestEasy</span>
        </div>
      </nav>

      <div id="content" className="re-content">
        <h2 className="timeline-title">Breathe. Reset. And Continue.</h2>
        <section>
          <h3>You Seem Stressed</h3>
          <div className="re-section-wrap">
            <div className="re-card">
              <img
                src={BeachImage}
                alt="Calm beach scenery"
              />
                <div className="re-card-body">

                  {/* Logic for the breathing instructions */}

                <p>Inhale deep for 4s, feel your lungs expand.</p>
                <p>Hold it for 4s.</p>
                <p>Exhale sharply for 5 seconds, out the nose.</p>
                <p>Repeat Thrice.</p>

                </div>

            </div>
            <div className="re-card">
              <img
                src={BreathingImage}
                alt="Breathing exercise visual"
              />
              <div className="re-card-body">


               Relax your shoulders. Feel The Worlds Presence. Rest Easy.

              </div>


            </div>
          </div>
        </section>
      </div>


      {/* Logic for the footer */}

      {/* Makes it feel like a real website */}


      <footer className="re-footer">
        <div className="re-footer-container">
          <div className="re-footer-column">
            <h3>About Us</h3>
            <p>
              We help those struggling with mental health and workplace stress through proven scientific methodologies
            </p>
          </div>
          <div className="re-footer-column">
            <h3>Contact Us</h3>
            <p>
              Email:{" "}
              <a href="mailto:info@RestEasyofficial.com">info@RestEasyofficial.com</a>
            </p>
            <p>Phone: +92-51-451-7676</p>
            <p>Address: Islamabad Capital Territory, Pakistan</p>
          </div>
        </div>
      </footer>
    </div>
  );
}



//The start of the actual logic for the application as a whole.



function App() {


  // Defines the state of the inbox, i.e when the mouse is clicked there.
  var [emails, setEmails] = useState([]);
  var [isLoggedIn, setIsLoggedIn] = useState(false);
  var [loading, setLoading] = useState(true);
  var [deletingIds, setDeletingIds] = useState(new Set());
  

  // Same as above, but for the compose logic
  // basically ensures when emails are being sent that state is existent.
  var [to, setTo] = useState("");
  var [subject, setSubject] = useState("");
  var [body, setBody] = useState("");



  // Start of the logic needed for the affective computing functionalities of the applicaotikn
  var [wpm, setWpm] = useState(0);
  var [showRestEasy, setShowRestEasy] = useState(false);


  // From here the WPM actually starts getting calucalted, 
  //this is the state when the mouse is on the body of the text
  var [readerOpen, setReaderOpen] = useState(false);
  var [readerLoading, setReaderLoading] = useState(false);
  var [selectedEmail, setSelectedEmail] = useState(null); 
  var [readerError, setReaderError] = useState("");



  // References needed to calculate the WPM like time etc.

  var keyTimesRef = useRef([]);    
  var lowSinceRef = useRef(null);    
  var bodyFocusedRef = useRef(false);



  // This is a very important part of the app.
  // Essenetially this ensures that when the WPM is below 5, the application does not count it for
  // being a condition to activate the calming state. If this logic didn't exist, the application would
  // enter the calming state every 8 seconds, even when idle, hence since 5 WPM is my personal consideration
  // to be an idle state and/or when youve accidently pressed a button or two, it doesnt count at that stage.
  
  
  var THRESHOLD_WPM = 25;   
  var IDLE_WPM = 5;         
  var WINDOW_MS = 5000;     
  var SUSTAIN_MS = 8000;    


  //variable that is used to connec tthe front react to the backend nodejs
  var backend = "http://localhost:5000";




  
  //logic to fetch data and email information from the backend


  var fetchEmails = useCallback(() => {


    setLoading(true);
    fetch(`${backend}/emails`, { credentials: "include" })
      .then((res) => {
        if (res.status === 401) {
          setIsLoggedIn(false);
          return [];
        }


        setIsLoggedIn(true);
        return res.json();
      })


      .then((data) => setEmails(Array.isArray(data) ? data : []))
      .catch(() => setEmails([]))
      .finally(() => setLoading(false));

  }, [backend]);



  useEffect(() => {
    fetchEmails();
  }, [fetchEmails]);



  // Ensures everything works with the OAuth app

  var login = () => {
    window.location.href = `${backend}/auth`;
  };


  //logic for the frontend of the logout functionality
  //once again, respects user privacy and safety concerns.


  var logout = () => {
    fetch(`${backend}/auth/logout`, {
      method: "POST",
      credentials: "include",
    }).finally(() => window.location.reload());
  };



  // Frontend logic for the send and delete functionaltieis of the application
  // also uses various HTTP methods, particularly POST

  var sendEmail = () => {


    fetch(`${backend}/emails/send`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify({ to, subject, body }),


    })


      .then((res) => res.json())
      .then((data) => {


        // some degree of error handling. 
        if (data?.success) {
          alert("Email sent!");
          setTo("");
          setSubject("");
          setBody("");
          fetchEmails(); 
        } else {
          alert(data?.error || "Failed to send email.");
        }
      })
      .catch(() => alert("Failed to send email."));


  };


  


  var deleteEmail = async (id) => {
    
    setDeletingIds((s) => new Set(s).add(id));
    setEmails((prev) => prev.filter((e) => e.id !== id));

    //more try and catch functions to achieve the very impt task of deleting
    // along with error handling

    try {


      var res = await fetch(`${backend}/emails/${id}`, {
        method: "DELETE",
        credentials: "include",
      });


      if (!res.ok) {
        var data = await res.json().catch(() => ({}));
        var msg =
          data?.error ||
          `Delete failed with status ${res.status}. Re-auth may be required.`;
        throw new Error(msg);
      }


    } catch (err) {
      alert(err.message);
      fetchEmails(); // rollback by refetch
    } finally {
      setDeletingIds((s) => {
        var n = new Set(s);
        n.delete(id);
        return n;


      });
    }
  };





  // this is for 
  // reading the proper and full emails


  var openReader = async (id) => {

    setReaderError("");
    setReaderLoading(true);
    setReaderOpen(true);


    try {
      var res = await fetch(`${backend}/emails/${id}`, { credentials: "include" });
      if (!res.ok) throw new Error(`Failed to load email (${res.status})`);
      var data = await res.json();
      setSelectedEmail(data);
    } 
    
    
    catch (e) {


      setReaderError(e.message || "Failed to load email");
      setSelectedEmail(null);
    } 
    
    finally {

      setReaderLoading(false);

    }
  };



  var closeReader = () => {
    setReaderOpen(false);
    setSelectedEmail(null);
    setReaderError("");
  };



  // Finally we get to the main functionality of the application,
  // the start of the affective computing functionalities application.
  //Some helper functions for the affective computing funciton are defined here


  function computeCurrentSpeed(now = Date.now()) {

  //logic to ensure WPM calculation remains instantaneous

    var arr = keyTimesRef.current;
    var cutoff = now - WINDOW_MS;
    while (arr.length && arr[0] < cutoff) arr.shift();


    var recentChars = arr.length;

    
    var currentWpm = Math.round((recentChars / 5) * (60000 / WINDOW_MS));
    return currentWpm;
  }

  

 
  useEffect(() => {
    var id = setInterval(() => {
      var now = Date.now();
      var current = computeCurrentSpeed(now);
      setWpm(current);

      if (!bodyFocusedRef.current) {
        lowSinceRef.current = null;
        return;
      }


      //all logic to define at what WPM what should be happening and what the app
      // should be thinking, basically, the functionality that detects the emotions of the user

      if (current >= THRESHOLD_WPM) {


        
        lowSinceRef.current = null;
      } else if (current <= IDLE_WPM) {

        
        lowSinceRef.current = null;
      } else {


        
        if (!lowSinceRef.current) lowSinceRef.current = now;
        if (now - lowSinceRef.current >= SUSTAIN_MS) {
          setShowRestEasy(true);


        }
      }
    }, 250);



    return () => clearInterval(id);
  }, []);






  // This is to show the calming applicaiotn interface, basically removes the email manager app


  if (showRestEasy) {
    return (
      <div className="re-wrap">
        <RestEasy />
        <div className="re-return">
          <button
            className="re-return-btn"
            onClick={() => {
              setShowRestEasy(false);


              
              keyTimesRef.current = [];
              setWpm(0);
              lowSinceRef.current = null;
            }}


          >
            ← Return to Compose
          </button>
        </div>
      </div>
    );
  }




  //HTML for the main application, it is messy to have both HTMLs in one file
  // but it works, and I was having trouble connecting both HTMls in separate files.


  return (


    <div className="app-root">
      <header className="topbar">
        <div className="brand">

          <span className="brand-name">RestEasy</span>
        </div>

        <div className="actions">
          {!isLoggedIn ? (
            <button className="btn primary" onClick={login}>
              Login with Google
            </button>


          ) : (
            <>
              <button className="btn ghost" onClick={fetchEmails} disabled={loading}>
                {loading ? "Refreshing…" : "Refresh"}
              </button>
              <button className="btn outline" onClick={logout}>
                Log out
              </button>
            </>
          )}
        </div>
      </header>


      {isLoggedIn ? (
        <main className="layout">
  
          {/* Logic to ensure the WPM calculator is interactive, and the user can see what the applicaiton is thinking 
          about their stress levels. Really helps with the dynamicness of the application and keeping the UI nice and intuitive. */}


          <section className="compose-panel">
            <div className="compose-head">
              <h2 className="panel-title">Compose</h2>
              <div


                className={`wpm ${
                  wpm >= THRESHOLD_WPM
                    ? "ok"
                    : wpm <= IDLE_WPM
                    ? "idle"
                    : "low"
                }`}
              >


                Speed: <strong>{wpm}</strong>
                {wpm <= IDLE_WPM
                  ? " (idle)"
                  : wpm < THRESHOLD_WPM
                  ? " (low)"
                  : ""}
              </div>
            </div>



            <div className="compose-grid">
              <input
                className="input"
                type="email"
                placeholder="Recipient"
                value={to}
                onChange={(e) => setTo(e.target.value)}
              />
              <input
                className="input"
                type="text"
                placeholder="Subject"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
              />
              <textarea
                className="textarea"
                placeholder="Message"
                value={body}
                onChange={(e) => setBody(e.target.value)}
                onKeyDown={(e) => {



                  // Ignores some keys that arent really used in typing, like ctrl, alt etc.
                  //ensures an accurate calculation for everything.
                  if (e.key.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
                    keyTimesRef.current.push(Date.now());
                  }
                }}


                onFocus={() => {
                  bodyFocusedRef.current = true;
                }}
                onBlur={() => {
                  bodyFocusedRef.current = false;
                  lowSinceRef.current = null;
                }}
                rows={10}
              />

              <div className="compose-actions">
                <button className="btn primary" onClick={sendEmail}>
                  Send
                </button>
                <button
                  className="btn ghost"
                  onClick={() => {
                    setTo("");
                    setSubject("");
                    setBody("");
                    keyTimesRef.current = [];
                    setWpm(0);
                    lowSinceRef.current = null;
                  }}
                >
                  Clear
                </button>
              </div>
            </div>
          </section>



          {/* The UI logic for the Inbox heading
          ZEnsures it is at the right, and the UI interface is in line with the design vision. */}


          <aside className="inbox-panel">
            <div className="inbox-head">
              <h3>Inbox</h3>
              <span className="pill">{emails.length}</span>
            </div>



            <div className="inbox-list">
              {loading ? (
                <div className="state muted">Loading Emails</div>
              ) : emails.length === 0 ? (
                <div className="state muted">No emails found</div>
              ) : (
                <ul className="mail-list">
                  {emails.map((email) => (
                    <li
                      key={email.id}
                      className="mail-card clickable"
                      onClick={() => openReader(email.id)}
                      title="Click to open"
                    >
                      <div className="mail-header">
                        <div className="mail-subject">
                          {email.subject || "(No Subject)"}
                        </div>
                        <button
                          className="btn tiny danger"
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteEmail(email.id);
                          }}
                          disabled={deletingIds.has(email.id)}
                          title={deletingIds.has(email.id) ? "Deleting…" : "Delete"}
                        >
                          {deletingIds.has(email.id) ? "…" : "🗑"}
                        </button>
                      </div>
                      <div className="mail-from">
                        <span className="dim">From:</span> {email.from || "(Unknown)"}
                      </div>
                      <p className="mail-snippet">{email.snippet}</p>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </aside>
        </main>
      ) : (
        <main className="login-wrap">
          <div className="card">
            <h2>Welcome</h2>
            <p className="muted">Sign in to view your inbox and compose emails</p>
            <button className="btn primary" onClick={login}>
              Login with Google
            </button>
          </div>
        </main>
      )}



      {/* Overlay that is necessary for the reader logic */}


      {readerOpen && (
        <div className="reader-overlay" onClick={closeReader}>
          <div className="reader-card" onClick={(e) => e.stopPropagation()}>
            <div className="reader-head">
              <div className="reader-title">
                <div className="reader-subject">
                  {selectedEmail?.subject || "(No Subject)"}
                </div>
                <div className="reader-meta">
                  {selectedEmail?.from && <span>{selectedEmail.from}</span>}
                  {selectedEmail?.date && <span> • {selectedEmail.date}</span>}
                </div>
              </div>
              <button className="btn outline" onClick={closeReader}>Close</button>
            </div>



            <div className="reader-body">
              {readerLoading ? (
                <div className="state muted">Loading…</div>
              ) : readerError ? (
                <div className="state muted">Error: {readerError}</div>
              ) : selectedEmail ? (
                selectedEmail.bodyHtml ? (


                  // Safe rendering of the HTML
                  //avoids potential conflicts


                  <iframe
                    title="email-body"
                    className="reader-iframe"
                    sandbox=""
                    srcDoc={selectedEmail.bodyHtml}
                  />
                ) : (
                  <div className="reader-plaintext">
                    {selectedEmail.bodyText
                      ?.split("\n")
                      .map((line, i) => <p key={i}>{line}</p>)}
                  </div>
                )
              ) : null}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}



//Exports the App and makes sure it works properly with Node/Express

export default App;
